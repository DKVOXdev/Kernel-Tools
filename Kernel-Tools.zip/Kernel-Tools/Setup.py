import sys
import os
import time

def afficher_chargement():
    for i in range(1, 101):
        print(f"\rChargement... {i}%", end="", flush=True)
        time.sleep(0.02)
    print()

def main():
    try:
        afficher_chargement()
        os.system("clear")
        print("Installation des modules Python requis :\n")
        os.system("pip install -r requirements.txt")  # pip fonctionne dans Termux
        os.system("python Kernel.py")  # ou python3 si Kernel.py nécessite ça

    except Exception as e:
        input(str(e))

if __name__ == "__main__":
    main()
