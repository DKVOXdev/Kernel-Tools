import requests
import json
import time
from datetime import datetime
import random

C = "\033[96m"
R = "\033[0m"

INFO = f"{C}[INFO]{R}"
INFO_ADD = f"{C}[+]{R}"
WAIT = f"{C}[WAIT]{R}"
ERROR = f"{C}[ERROR]{R}"
INPUT = f"{C}[INPUT]{R}"

def current_time_hour():
    return datetime.now().strftime("%H:%M:%S")

def Error(message):
    print(f"[{current_time_hour()}] {ERROR} {message}{R}")
    input(f"{C}Press Enter to exit...{R}")
    exit(1)

def Continue():
    input(f"{C}Press Enter to continue...{R}")

def Reset():
    pass

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36"
]

def ChoiceUserAgent():
    return random.choice(USER_AGENTS)

def main():
    try:
        user_agent = ChoiceUserAgent()
        headers = {"User-Agent": user_agent}

        print(f"[{current_time_hour()}] {INFO} Selected User-Agent: {C}{user_agent}{R}")
        
        cookie = input(f"[{current_time_hour()}] {INPUT} Cookie Roblox info -> {C}").strip()
        if not cookie:
            Error("Cookie cannot be empty.")

        print(f"[{current_time_hour()}] {WAIT} Information Recovery...{R}")
        
        try:
            response = requests.get(
                "https://www.roblox.com/mobileapi/userinfo",
                headers=headers,
                cookies={".ROBLOSECURITY": cookie}
            )
            
            if response.status_code != 200:
                raise ValueError(f"API returned status code {response.status_code}")

            api = response.json()
            
            status = "Valid"
            username_roblox = api.get('UserName', "None")
            user_id_roblox = api.get("UserID", "None")
            robux_roblox = api.get("RobuxBalance", "None")
            premium_roblox = api.get("IsPremium", "None")
            avatar_roblox = api.get("ThumbnailUrl", "None")
            builders_club_roblox = api.get("IsAnyBuildersClubMember", "None")
        
        except (requests.exceptions.RequestException, ValueError, json.JSONDecodeError) as e:
            status = "Invalid"
            username_roblox = "None"
            user_id_roblox = "None"
            robux_roblox = "None"
            premium_roblox = "None"
            avatar_roblox = "None"
            builders_club_roblox = "None"
            print(f"[{current_time_hour()}] {ERROR} Invalid cookie or API error: {e}{R}")

        print(f"""
{C}────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
 {INFO_ADD} Status        : {C}{status}{R}
 {INFO_ADD} Username      : {C}{username_roblox}{R}
 {INFO_ADD} Id            : {C}{user_id_roblox}{R}
 {INFO_ADD} Robux         : {C}{robux_roblox}{R}
 {INFO_ADD} Premium       : {C}{premium_roblox}{R}
 {INFO_ADD} Builders Club : {C}{builders_club_roblox}{R}
 {INFO_ADD} Avatar        : {C}{avatar_roblox}{R}
{C}────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
        """)

        Continue()
        Reset()

    except Exception as e:
        Error(f"Unexpected error: {e}")

if __name__ == "__main__":
    main()
