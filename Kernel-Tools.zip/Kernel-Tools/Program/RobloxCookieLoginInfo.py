import sys
import time
import random
from datetime import datetime
try:
    from selenium import webdriver
    from selenium.webdriver.common.by import By
except ImportError as e:
    print(f"[ERROR] Failed to import selenium: {e}")
    input("Press Enter to exit...")
    exit(1)

C = "\033[96m"
R = "\033[0m"

INFO = f"{C}[INFO]{R}"
WAIT = f"{C}[WAIT]{R}"
ERROR = f"{C}[ERROR]{R}"
INPUT = f"{C}[INPUT]{R}"

def current_time_hour():
    return datetime.now().strftime("%H:%M:%S")

def Error(message):
    print(f"[{current_time_hour()}] {ERROR} {message}{R}")
    input(f"{C}Press Enter to exit...{R}")
    exit(1)

def ErrorChoice():
    print(f"[{current_time_hour()}] {ERROR} Invalid browser choice. Please select 1, 2, or 3.{R}")
    input(f"{C}Press Enter to continue...{R}")
    exit(1)

def Continue():
    input(f"{C}Press Enter to continue...{R}")

def Reset():
    pass

def OnlyLinux():
    print(f"[{current_time_hour()}] {ERROR} Edge and Firefox are not supported on Linux in this script.{R}")
    input(f"{C}Press Enter to continue...{R}")
    exit(1)

def main():
    try:
        cookie = input(f"\n[{current_time_hour()}] {INPUT} login Cookie Roblox -> {C}").strip()
        if not cookie:
            Error("Cookie cannot be empty.")

        print(f"""
 [{current_time_hour()}] {C}Browser Options:
 {C}[01]{C} Chrome (Windows / Linux)
 {C}[02]{C} Edge (Windows)
 {C}[03]{C} Firefox (Windows)
        """)
        browser = input(f"[{current_time_hour()}] {INPUT} Browser -> {R}").strip()

        driver = None
        navigator = None
        if browser in ['1', '01']:
            navigator = "Chrome"
            print(f"[{current_time_hour()}] {WAIT} {navigator} Starting...{C}")
            try:
                driver = webdriver.Chrome()
                print(f"[{current_time_hour()}] {INFO} {navigator} Ready!{C}")
            except Exception as e:
                Error(f"{navigator} not installed or driver not up to date: {e}")

        elif browser in ['2', '02']:
            if sys.platform.startswith("linux"):
                OnlyLinux()
            navigator = "Edge"
            print(f"[{current_time_hour()}] {WAIT} {navigator} Starting...{C}")
            try:
                driver = webdriver.Edge()
                print(f"[{current_time_hour()}] {INFO} {navigator} Ready!{C}")
            except Exception as e:
                Error(f"{navigator} not installed or driver not up to date: {e}")

        elif browser in ['3', '03']:
            if sys.platform.startswith("linux"):
                OnlyLinux()
            navigator = "Firefox"
            print(f"[{current_time_hour()}] {WAIT} {navigator} Starting...{C}")
            try:
                driver = webdriver.Firefox()
                print(f"[{current_time_hour()}] {INFO} {navigator} Ready!{C}")
            except Exception as e:
                Error(f"{navigator} not installed or driver not up to date: {e}")

        else:
            ErrorChoice()

        try:
            driver.get("https://www.roblox.com/Login")
            print(f"[{current_time_hour()}] {WAIT} Cookie Connection...{C}")
            driver.add_cookie({"name": ".ROBLOSECURITY", "value": cookie})
            print(f"[{current_time_hour()}] {INFO} Connected Cookie!{C}")
            print(f"[{current_time_hour()}] {WAIT} Refreshing The Page...{C}")
            driver.refresh()
            print(f"[{current_time_hour()}] {INFO} Connected!{C}")
            time.sleep(1)
            driver.get("https://www.roblox.com/users/profile")
            print(f"[{current_time_hour()}] {INFO} If you leave the tool, {navigator} will close!{C}")
            Continue()

        except Exception as e:
            Error(f"Error during login process: {e}")

        finally:
            if driver:
                try:
                    driver.quit()
                    print(f"[{current_time_hour()}] {INFO} {navigator} Closed!{C}")
                except:
                    pass

        Reset()

    except Exception as e:
        Error(f"Unexpected error: {e}")

if __name__ == "__main__":
    main()
