import requests
import time
from datetime import datetime
import random

C = "\033[96m"
R = "\033[0m"

INFO = f"{C}[INFO]{R}"
INFO_ADD = f"{C}[+]{R}"
WAIT = f"{C}[WAIT]{R}"
ERROR = f"{C}[ERROR]{R}"
INPUT = f"{C}[INPUT]{R}"

def current_time_hour():
    return datetime.now().strftime("%H:%M:%S")

def Error(message):
    print(f"[{current_time_hour()}] {ERROR} {message}{R}")
    input(f"{C}Appuyez sur Entrée pour quitter...{R}")
    exit(1)

def ErrorId():
    print(f"[{current_time_hour()}] {ERROR} ID utilisateur invalide ou erreur API.{R}")
    input(f"{C}Appuyez sur Entrée pour continuer...{R}")
    exit(1)

def Continue():
    input(f"{C}Appuyez sur Entrée pour continuer...{R}")

def Reset():
    pass

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36"
]

def ChoiceUserAgent():
    return random.choice(USER_AGENTS)

def main():
    try:
        user_agent = ChoiceUserAgent()
        headers = {"User-Agent": user_agent}

        print(f"[{current_time_hour()}] {INFO} Selected User-Agent: {C}{user_agent}{R}")
        
        user_id = input(f"[{current_time_hour()}] {INPUT} ID Roblox -> {R}").strip()
        if not user_id.isdigit():
            ErrorId()
        
        print(f"[{current_time_hour()}] {WAIT} Information Recovery...{R}")
        
        response = requests.get(f"https://users.roblox.com/v1/users/{user_id}", headers=headers)
        if response.status_code != 200:
            ErrorId()
        
        api = response.json()
        userid = api.get('id', "None")
        display_name = api.get('displayName', "None")
        username = api.get('name', "None")
        description = api.get('description', "None")
        created_at = api.get('created', "None")
        is_banned = api.get('isBanned', "None")
        external_app_display_name = api.get('externalAppDisplayName', "None")
        has_verified_badge = api.get('hasVerifiedBadge', "None")

        print(f"""
{C}────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
 {INFO_ADD} Username       : {C}{username}{R}
 {INFO_ADD} Id             : {C}{userid}{R}
 {INFO_ADD} Display Name   : {C}{display_name}{R}
 {INFO_ADD} Description    : {C}{description}{R}
 {INFO_ADD} Created        : {C}{created_at}{R}
 {INFO_ADD} Banned         : {C}{is_banned}{R}
 {INFO_ADD} External Name  : {C}{external_app_display_name}{R}
 {INFO_ADD} Verified Badge : {C}{has_verified_badge}{R}
{C}────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
        """)

        Continue()
        Reset()

    except requests.exceptions.RequestException as e:
        Error(f"Erreur lors de la requête API : {e}")
    except ValueError as e:
        ErrorId()
    except Exception as e:
        Error(f"Erreur inattendue : {e}")

if __name__ == "__main__":
    main()
