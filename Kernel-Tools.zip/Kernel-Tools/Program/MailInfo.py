#!/usr/bin/env python3
import os
import re
import dns.resolver

BLUE = "\033[96m"
RESET = "\033[0m"

logo = r"""
          ███▄ ▄███▓ ▄▄▄       ██▓ ██▓        ██▓ ███▄    █   █████▒▒█████
         ▓██▒▀█▀ ██▒▒████▄    ▓██▒▓██▒       ▓██▒ ██ ▀█   █ ▓██   ▒▒██▒  ██▒
         ▓██    ▓██░▒██  ▀█▄  ▒██▒▒██░       ▒██▒▓██  ▀█ ██▒▒████ ░▒██░  ██▒
         ▒██    ▒██ ░██▄▄▄▄██ ░██░▒██░       ░██░▓██▒  ▐▌██▒░▓█▒  ░▒██   ██░
         ▒██▒   ░██▒ ▓█   ▓██▒░██░░██████▒   ░██░▒██░   ▓██░░▒█░   ░ ████▓▒░
         ░ ▒░   ░  ░ ▒▒   ▓▒█░░▓  ░ ▒░▓  ░   ░▓  ░ ▒░   ▒ ▒  ▒ ░   ░ ▒░▒░▒░
         ░  ░      ░  ▒   ▒▒ ░ ▒ ░░ ░ ▒  ░    ▒ ░░ ░░   ░ ▒░ ░       ░ ▒ ▒░
         ░      ░     ░   ▒    ▒ ░  ░ ░       ▒ ░   ░   ░ ░  ░ ░   ░ ░ ░ ▒
                ░         ░  ░ ░      ░  ░    ░           ░            ░ ░
"""

resolver = dns.resolver.Resolver(configure=False)
resolver.nameservers = ['8.8.8.8', '8.8.4.4']

def get_email_info(email):
    info = {}
    domain_all = email.split('@')[-1] if '@' in email else None
    name = email.split('@')[0] if '@' in email else None
    domain = re.search(r"@([^@.]+)\.", email)
    domain = domain.group(1) if domain else None
    tld = f".{email.split('.')[-1]}" if '.' in email else None

    try:
        mx_records = resolver.resolve(domain_all, 'MX')
        info["mx_servers"] = [str(record.exchange) for record in mx_records]
    except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN):
        info["mx_servers"] = None

    try:
        spf_records = resolver.resolve(domain_all, 'SPF')
        info["spf_records"] = [str(record) for record in spf_records]
    except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN):
        info["spf_records"] = None

    try:
        dmarc_records = resolver.resolve(f'_dmarc.{domain_all}', 'TXT')
        info["dmarc_records"] = [str(record) for record in dmarc_records]
    except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN):
        info["dmarc_records"] = None

    if info.get("mx_servers"):
        for server in info["mx_servers"]:
            if "google.com" in server:
                info["google_workspace"] = True
            elif "outlook.com" in server:
                info["microsoft_365"] = True

    return info, domain_all, domain, tld, name

def main():
    os.system('cls' if os.name == 'nt' else 'clear')
    print(f"{BLUE}{logo}{RESET}")
    email = input(f"{BLUE}Email >> {RESET}")
    os.system('cls' if os.name == 'nt' else 'clear')
    print(f"{BLUE}{logo}{RESET}")

    info, domain_all, domain, tld, name = get_email_info(email)

    mx_servers = ' / '.join(info.get("mx_servers", [])) if info.get("mx_servers") else None
    spf_records = info.get("spf_records")
    dmarc_records = ' / '.join(info.get("dmarc_records", [])) if info.get("dmarc_records") else None
    google_workspace = info.get("google_workspace", None)
    microsoft_365 = info.get("microsoft_365", None)

    print(f"""
[+] Email         : {email}
[+] Name          : {name}
[+] Domain        : {domain}
[+] TLD           : {tld}
[+] Domain All    : {domain_all}
[+] MX Servers    : {mx_servers}
[+] SPF Records   : {spf_records}
[+] DMARC         : {dmarc_records}
[+] Google WS     : {google_workspace}
[+] Microsoft 365 : {microsoft_365}
    """)

if __name__ == "__main__":
    main()
