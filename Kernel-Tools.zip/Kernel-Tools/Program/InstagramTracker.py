#!/usr/bin/env python3
import instaloader
import sys
import os
from contextlib import contextmanager

BLUE = "\033[96m"
RESET = "\033[0m"

@contextmanager
def suppress_output():
    with open(os.devnull, 'w') as devnull:
        old_stdout = sys.stdout
        old_stderr = sys.stderr
        sys.stdout = devnull
        sys.stderr = devnull
        try:
            yield
        finally:
            sys.stdout = old_stdout
            sys.stderr = old_stderr

def get_profile(username):
    loader = instaloader.Instaloader(download_pictures=False,
                                     download_videos=False,
                                     download_video_thumbnails=False,
                                     download_geotags=False,
                                     download_comments=False,
                                     save_metadata=False,
                                     compress_json=False)
    with suppress_output():
        profile = instaloader.Profile.from_username(loader.context, username)
    return profile

def main():
    username = input(f"{BLUE}🔎 Nom du compte Instagram à rechercher -> {RESET}").strip()

    try:
        profile = get_profile(username)
    except Exception:
        print(f"{BLUE}❌ Username introuvable{RESET}")
        sys.exit(0)

    print(f"{BLUE}──────────────────────────────────────────────────────────────{RESET}")
    print(f"{BLUE}👤 Nom complet       : {profile.full_name}{RESET}")
    print(f"{BLUE}📛 Nom d'utilisateur : {profile.username}{RESET}")
    print(f"{BLUE}🆔 Instagram Id     : {profile.userid}{RESET}")
    print(f"{BLUE}📝 Biographie       : {profile.biography}{RESET}")
    print(f"{BLUE}🔗 URL Profil       : https://instagram.com/{profile.username}{RESET}")
    print(f"{BLUE}🖼️ Photo Profil     : {profile.profile_pic_url}{RESET}")
    print(f"{BLUE}📷 Publications    : {profile.mediacount}{RESET}")
    print(f"{BLUE}👥 Abonnés         : {profile.followers}{RESET}")
    print(f"{BLUE}👣 Abonnements     : {profile.followees}{RESET}")
    print(f"{BLUE}✔️ Vérifié          : {'Oui' if profile.is_verified else 'Non'}{RESET}")
    print(f"{BLUE}🔒 Compte Privé    : {'Oui' if profile.is_private else 'Non'}{RESET}")
    print(f"{BLUE}🏢 Compte Pro      : {'Oui' if profile.is_business_account else 'Non'}{RESET}")

    if profile.is_business_account:
        print(f"{BLUE}🏷️ Catégorie Pro   : {profile.business_category_name}{RESET}")
    print(f"{BLUE}──────────────────────────────────────────────────────────────{RESET}")

    if not profile.is_private:
        try:
            posts = profile.get_posts()
            for i, post in enumerate(posts):
                print(f"{BLUE}📌 Publication n°{i+1}{RESET}")
                print(f"{BLUE}🔗 URL       : https://www.instagram.com/p/{post.shortcode}/{RESET}")
                print(f"{BLUE}📅 Date      : {post.date}{RESET}")
                print(f"{BLUE}❤️ Likes     : {post.likes}{RESET}")
                print(f"{BLUE}💬 Commentaires : {post.comments}{RESET}")
                print(f"{BLUE}📝 Légende   : {post.caption if post.caption else 'Pas de légende'}{RESET}")
                print(f"{BLUE}──────────────────────────────────────────────────────────────{RESET}")
                if i == 4:
                    break
        except Exception:
            pass
    else:
        print(f"{BLUE}🔒 Le compte est privé, impossible de récupérer les publications.{RESET}")

if __name__ == "__main__":
    main()
