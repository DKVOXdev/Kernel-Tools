import os
import requests
import time

BLUE = "\033[96m"
BOLD = "\033[1m"
RESET = "\033[0m"
RED = "\033[31m"
GREEN = "\033[32m"

menu = f"""
         {BLUE}▓█████▄  ███▄ ▄███▓ ▄▄▄       ██▓     ██▓
         ▒██▀ ██▌▓██▒▀█▀ ██▒▒████▄    ▓██▒    ▓██▒
         ░██   █▌▓██    ▓██░▒██  ▀█▄  ▒██░    ▒██░
         ░▓█▄   ▌▒██    ▒██ ░██▄▄▄▄██ ▒██░    ▒██░
         ░▒████▓ ▒██▒   ░██▒ ▓█   ▓██▒░██████▒░██████▒
         ▒▒▓  ▒ ░ ▒░   ░  ░ ▒▒   ▓▒█░░ ▒░▓  ░░ ▒░▓  ░
           ░ ▒  ▒ ░  ░      ░  ▒   ▒▒ ░░ ░ ▒  ░░ ░ ▒  ░
           ░ ░  ░ ░      ░     ░   ▒     ░ ░     ░ ░
             ░           ░         ░  ░    ░  ░    ░  ░
           ░{RESET}
"""
menu2 = f"""
{BOLD}[0]{RESET} {BLUE}Back to main
[1] {BLUE}Dmall Friends (SelfBot)
[2] {BLUE}Dmall Dm Open (SelfBot)
[3] {BLUE}Dmall Server (Bot){RESET}
"""

def show_menu():
    print(menu)
    print(menu2)

def dmall_friends(token_discord):
    message = input(f'{BLUE}Message ({BLUE}{{user}}{BLUE} pour mentionner): {RESET}')
    header = {'Authorization': token_discord, 'Content-Type': 'application/json'}

    try:
        response = requests.get('https://discord.com/api/v9/users/@me/relationships', headers=header)
        if response.status_code != 200:
            print(f"{RED}[!] Erreur lors de la récupération des amis ({response.status_code}){RESET}")
            return

        friends = response.json()
        for friend in friends:
            try:
                user_id = friend['user']['id']
                username = friend['user']['username']
                discriminator = friend['user']['discriminator']
                mention = f"<@{user_id}>"
                user_message = message.replace("{user}", mention)

                try:
                    channel_response = requests.post(
                        'https://discord.com/api/v9/users/@me/channels',
                        headers=header,
                        json={"recipient_id": user_id}
                    )
                    if channel_response.status_code != 200:
                        print(f"{RED}[!] Erreur lors de la création du canal pour {username}#{discriminator} ({channel_response.status_code}){RESET}")
                        continue

                    channel_id = channel_response.json()['id']
                    dm_response = requests.post(
                        f'https://discord.com/api/v9/channels/{channel_id}/messages',
                        headers=header,
                        json={"content": user_message}
                    )

                    if dm_response.status_code == 200:
                        print(f"{GREEN}[+] Message envoyé à {username}#{discriminator}{RESET}")
                    else:
                        print(f"{RED}[!] Message non envoyé à {username}#{discriminator} ({dm_response.status_code}){RESET}")

                    time.sleep(0.5)

                except Exception as e:
                    print(f"{RED}[!] Erreur : {e}{RESET}")

            except KeyError as e:
                print(f"{RED}[!] Clé manquante dans la réponse : {e}{RESET}")
                print(f"Réponse complète pour cet utilisateur : {friend}{RESET}")

    except Exception as e:
        print(f"{RED}[!] Erreur lors de la récupération des amis : {e}{RESET}")

def dmall_open(token_discord):
    message = input(f'{BLUE}Message ({BLUE}{{user}}{BLUE} pour mentionner): {RESET}')
    header = {'Authorization': token_discord, 'Content-Type': 'application/json'}

    try:
        response = requests.get('https://discord.com/api/v9/users/@me/channels', headers=header)
        if response.status_code != 200:
            print(f"{RED}[!] Erreur lors de la récupération des DM ouverts ({response.status_code}){RESET}")
            return

        open_dms = response.json()
        for dm in open_dms:
            try:
                user_id = dm['recipients'][0]['id']
                username = dm['recipients'][0]['username']
                discriminator = dm['recipients'][0]['discriminator']
                mention = f"<@{user_id}>"
                user_message = message.replace("{user}", mention)

                dm_response = requests.post(
                    f'https://discord.com/api/v9/channels/{dm["id"]}/messages',
                    headers=header,
                    json={"content": user_message}
                )

                if dm_response.status_code == 200:
                    print(f"{GREEN}[+] Message envoyé à {username}#{discriminator}{RESET}")
                else:
                    print(f"{RED}[!] Message non envoyé à {username}#{discriminator} ({dm_response.status_code}){RESET}")

                time.sleep(0.5)
            except Exception as e:
                print(f"{RED}[!] Erreur : {e}{RESET}")

    except Exception as e:
        print(f"{RED}[!] Erreur lors de la récupération des DM ouverts : {e}{RESET}")

def dmall_server(token_bot, server_id):
    message = input(f'{BLUE}Message ({BLUE}{{user}}{BLUE} pour mentionner): {RESET}')
    header = {'Authorization': f'Bot {token_bot}', 'Content-Type': 'application/json'}

    try:
        response = requests.get(f'https://discord.com/api/v9/guilds/{server_id}/members?limit=1000', headers=header)
        if response.status_code != 200:
            print(f"{RED}[!] Erreur lors de la récupération des membres du serveur ({response.status_code}){RESET}")
            return

        members = response.json()
        for member in members:
            try:
                user_id = member['user']['id']
                username = member['user']['username']
                discriminator = member['user']['discriminator']
                mention = f"<@{user_id}>"
                user_message = message.replace("{user}", mention)

                try:
                    channel_response = requests.post(
                        'https://discord.com/api/v9/users/@me/channels',
                        headers=header,
                        json={"recipient_id": user_id}
                    )
                    if channel_response.status_code != 200:
                        print(f"{RED}[!] Erreur lors de la création du canal pour {username}#{discriminator} ({channel_response.status_code}){RESET}")
                        continue

                    channel_id = channel_response.json()['id']
                    dm_response = requests.post(
                        f'https://discord.com/api/v9/channels/{channel_id}/messages',
                        headers=header,
                        json={"content": user_message}
                    )

                    if dm_response.status_code == 200:
                        print(f"{GREEN}[+] Message envoyé à {username}#{discriminator}{RESET}")
                    else:
                        print(f"{RED}[!] Erreur lors de l'envoi du message à {username}#{discriminator} ({dm_response.status_code}){RESET}")

                    time.sleep(0.5)

                except Exception as e:
                    print(f"{RED}[!] Erreur : {e}{RESET}")

            except KeyError as e:
                print(f"{RED}[!] Clé manquante dans la réponse : {e}{RESET}")
                print(f"Réponse complète pour cet utilisateur : {member}{RESET}")

    except Exception as e:
        print(f"{RED}[!] Erreur : {e}{RESET}")

def main():
    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        show_menu()
        try:
            choice = int(input(f'{BLUE}Choice >> {RESET}'))

            if choice == 0:
                os.system('python kernel.py')
                break
            elif choice == 1:
                os.system('cls' if os.name == 'nt' else 'clear')
                print(menu)
                token_discord = input(f'{BLUE}Token : {RESET}')
                dmall_friends(token_discord)
            elif choice == 2:
                os.system('cls' if os.name == 'nt' else 'clear')
                print(menu)
                token_discord = input(f'{BLUE}Token : {RESET}')
                dmall_open(token_discord)
            elif choice == 3:
                os.system('cls' if os.name == 'nt' else 'clear')
                print(menu)
                token_bot = input(f'{BLUE}Token : {RESET}')
                server_id = input(f'{BLUE}Guild ID : {RESET}')
                dmall_server(token_bot, server_id)
            else:
                print(f"{RED}[!] > Invalid choice < [!]{RESET}")
        except ValueError:
            print(f"{RED}[!] Please enter a valid number{RESET}")
        input(f"\nPress Enter to return to the main menu...{RESET}")

if __name__ == "__main__":
    main()
