#!/usr/bin/env python3
import phonenumbers
from phonenumbers import geocoder, carrier, timezone
import os
import time

BLUE = "\033[96m"
RESET = "\033[0m"

logo = r"""
         ███▄    █  █    ██  ███▄ ▄███▓ ▄▄▄▄   ▓█████  ██▀███
         ██ ▀█   █  ██  ▓██▒▓██▒▀█▀ ██▒▓█████▄ ▓█   ▀ ▓██ ▒ ██▒
         ▓██  ▀█ ██▒▓██  ▒██░▓██    ▓██░▒██▒ ▄██▒███   ▓██ ░▄█ ▒
         ▓██▒  ▐▌██▒▓▓█  ░██░▒██    ▒██ ▒██░█▀  ▒▓█  ▄ ▒██▀▀█▄
         ▒██░   ▓██░▒▒█████▓ ▒██▒   ░██▒░▓█  ▀█▓░▒████▒░██▓ ▒██▒
         ░ ▒░   ▒ ▒ ░▒▓▒ ▒ ▒ ░ ▒░   ░  ░░▒▓███▀▒░░ ▒░ ░░ ▒▓ ░▒▓░
         ░ ░░   ░ ▒░░░▒░ ░ ░ ░  ░      ░▒░▒   ░  ░ ░  ░  ░▒ ░ ▒░
         ░   ░ ░  ░░░ ░ ░ ░      ░    ░    ░    ░     ░░   ░
             ░    ░            ░    ░         ░  ░   ░                                                                         ░
"""

def track_phone_number(phone_number):
    phone_number = ''.join(filter(str.isdigit, phone_number))
    try:
        parsed_number = phonenumbers.parse(f"+{phone_number}", None)
        if not phonenumbers.is_valid_number(parsed_number):
            print(f"{BLUE}[!] Numéro invalide [!]{RESET}")
            return
        
        number_info = {
            "Country": geocoder.description_for_number(parsed_number, 'en'),
            "ISP": carrier.name_for_number(parsed_number, 'en'),
            "Time Zone": ", ".join(timezone.time_zones_for_number(parsed_number)),
            "National Number": phonenumbers.format_number(parsed_number, phonenumbers.PhoneNumberFormat.NATIONAL),
            "International Number": phonenumbers.format_number(parsed_number, phonenumbers.PhoneNumberFormat.INTERNATIONAL),
            "E.164 Format": phonenumbers.format_number(parsed_number, phonenumbers.PhoneNumberFormat.E164),
            "Number Type": phonenumbers.number_type(parsed_number),
            "Possible Number": phonenumbers.is_possible_number(parsed_number)
        }
        
        print(f"{BLUE}Recherche pour le numéro '+{phone_number}'..\n{RESET}")
        time.sleep(1)
        for key, value in number_info.items():
            print(f"{BLUE}{key}: {value}{RESET}")
    
    except phonenumbers.NumberParseException:
        print(f"{BLUE}[!] Username introuvable / Numéro invalide [!]{RESET}")

def main():
    os.system('cls' if os.name == 'nt' else 'clear')
    print(f"{BLUE}{logo}{RESET}")
    phone_number = input(f"{BLUE}📞 Numéro de téléphone >> {RESET}")
    os.system('cls' if os.name == 'nt' else 'clear')
    print(f"{BLUE}{logo}{RESET}")
    track_phone_number(phone_number)

if __name__ == "__main__":
    main()
