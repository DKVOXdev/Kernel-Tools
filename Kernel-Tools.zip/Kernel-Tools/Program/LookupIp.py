#!/usr/bin/env python3
import os
import subprocess
import socket
import concurrent.futures
import platform
import requests

BLUE = "\033[96m"
RESET = "\033[0m"

logo = r"""
      ██▓ ██▓███      ██▓     ▒█████   ▒█████   ██ ▄█▀ █    ██  ██▓███
      ▓██▒▓██░  ██▒   ▓██▒    ▒██▒  ██▒▒██▒  ██▒ ██▄█▒  ██  ▓██▒▓██░  ██▒
      ▒██▒▓██░ ██▓▒   ▒██░    ▒██░  ██▒▒██░  ██▒▓███▄░ ▓██  ▒██░▓██░ ██▓▒
      ░██░▒██▄█▓▒ ▒   ▒██░    ▒██   ██░▒██   ██░▓██ █▄ ▓▓█  ░██░▒██▄█▓▒ ▒
      ░██░▒██▒ ░  ░   ░██████▒░ ████▓▒░░ ████▓▒░▒██▒ █▄▒▒█████▓ ▒██▒ ░  ░
      ░▓  ▒▓▒░ ░  ░   ░ ▒░▓  ░░ ▒░▒░▒░ ░ ▒░▒░▒░ ▒ ▒▒ ▓▒░▒▓▒ ▒ ▒ ▒▓▒░ ░  ░
      ▒ ░░▒ ░        ░ ░ ▒  ░  ░ ▒ ▒░   ░ ▒ ▒░ ░ ░▒ ▒░░░▒░ ░ ░ ░▒ ░
      ▒ ░░░            ░ ░   ░ ░ ░ ▒  ░ ░ ░ ▒  ░ ░░ ░  ░░░ ░ ░ ░░
      ░                  ░  ░    ░ ░      ░ ░  ░  ░      ░
"""

def ip_info(ip_address):
    response = requests.get(f'http://ip-api.com/json/{ip_address}')
    if response.status_code == 200:
        data = response.json()
        if data['status'] == 'success':
            lat, lon = data.get('lat', 0), data.get('lon', 0)
            maps_url = f"https://www.google.com/maps/search/?api=1&query={lat},{lon}"
            result = {
                "IP": ip_address,
                "Pays": data.get('country', 'N/A'),
                "Ville": data.get('city', 'N/A'),
                "Région": data.get('regionName', 'N/A'),
                "ZIP": data.get('zip', 'N/A'),
                "ISP": data.get('isp', 'N/A'),
                "Fuseau horaire": data.get('timezone', 'N/A'),
                "Latitude": lat,
                "Longitude": lon,
                "Google Maps": maps_url
            }
            for key, value in result.items():
                print(f"{BLUE}{key} : {value}{RESET}")
        else:
            print(f"{BLUE}Veuillez vérifier l'adresse IP et réessayer.{RESET}")
    else:
        print(f"{BLUE}Veuillez réessayer plus tard (API).{RESET}")

def ping_ip(ip_address):
    param = '-n' if platform.system().lower() == 'windows' else '-c'
    try:
        result = subprocess.run(['ping', param, '4', ip_address], capture_output=True, text=True, timeout=10)
        print(f"{BLUE}\n{'=' * 60}\nPING {ip_address}\n{'=' * 60}{RESET}")
        print(f"{BLUE}{result.stdout}{RESET}")
    except subprocess.TimeoutExpired:
        print(f"{BLUE}Le ping a expiré (Timeout).{RESET}")
    except Exception as e:
        print(f"{BLUE}Erreur : {e}{RESET}")

def scan_port(ip_address):
    open_ports = []
    print(f"{BLUE}Scanning ports on {ip_address}...{RESET}")
    with concurrent.futures.ThreadPoolExecutor(max_workers=100) as executor:
        futures = {executor.submit(scan_single_port, ip_address, port): port for port in range(1, 1025)}
        for future in concurrent.futures.as_completed(futures):
            port = futures[future]
            if future.result():
                open_ports.append(port)
                print(f"{BLUE}Port {port} ouvert{RESET}")
    if open_ports:
        print(f"{BLUE}\n{'=' * 60}\nOPEN PORTS\n{'=' * 60}\nPorts Ouverts: {open_ports}{RESET}")
    else:
        print(f"{BLUE}Aucun port ouvert trouvé.{RESET}")

def scan_single_port(ip_address, port):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)
        result = sock.connect_ex((ip_address, port))
        sock.close()
        return result == 0
    except Exception:
        return False

def reverse_dns(ip_address):
    try:
        result = subprocess.run(['nslookup', ip_address], capture_output=True, text=True)
        print(f"{BLUE}\n{'=' * 60}\nREVERSE DNS {ip_address}\n{'=' * 60}{RESET}")
        print(f"{BLUE}{result.stdout}{RESET}")
    except Exception as e:
        print(f"{BLUE}Erreur : {e}{RESET}")

def whois_lookup(ip_address):
    try:
        result = subprocess.run(['whois', ip_address], capture_output=True, text=True)
        print(f"{BLUE}\n{'=' * 60}\nWHOIS {ip_address}\n{'=' * 60}{RESET}")
        print(f"{BLUE}{result.stdout}{RESET}")
    except FileNotFoundError:
        print(f"{BLUE}La commande 'whois' n'a pas été trouvée.{RESET}")
    except Exception as e:
        print(f"{BLUE}Erreur : {e}{RESET}")

def main():
    os.system('cls' if os.name == 'nt' else 'clear')
    print(f"{BLUE}{logo}{RESET}")
    ip_address = input(f"{BLUE}Adresse IP >> {RESET}").strip()
    os.system('cls' if os.name == 'nt' else 'clear')
    print(f"{BLUE}{logo}{RESET}")
    ip_info(ip_address)
    ping_ip(ip_address)
    scan_port(ip_address)
    reverse_dns(ip_address)
    whois_lookup(ip_address)

if __name__ == "__main__":
    main()
