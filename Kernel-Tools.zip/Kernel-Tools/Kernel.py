#!/usr/bin/env python3
import os
import subprocess
import sys
import time
import platform
import Program

C = "\033[96m"
R = "\033[0m"
B = "\033[1m"

ASCII_LOGO = r"""
 _        _______  _______  _        _______  _                   __
| \    /$$  ____ $$  ____ )( (    /|(  ____ $$ \        |\     /|/  \
|  \  / /| (    \/| (    )||  \  ( || (    \/| (        | )   ( |\/ ) )
|  (_/ / | (__    | (____)||   \ | || (__    | |        | |   | |  | |
|   _ (  |  __)   |     __)| (\ $$ ||  __)   | |        ( (   ) )  | |
|  ( \ \ | (      | (\ (   | | \   || (      | |         \ \_/ /   | |
|  /  \ \| (____/\| ) \ \__| )  \  || (____/\| (____/\    \   /  __) (_
|_/    \/(_______/|/   \__/|/    )_)(_______/(_______/     \_/   \____/
"""

FRAME = [
    "╔══════════════════╗",
    "║   Multi-Tool     ║",
    "║     by DKVOX     ║",
    "╚══════════════════╝"
]

IS_WINDOWS = os.name == "nt"
IS_TERMUX = "com.termux" in platform.uname().release or "android" in platform.system().lower()

HOME_DIR = os.path.expanduser("~")
ROOT = os.path.join(HOME_DIR, "Kernel-Tools")
PROGRAM = os.path.join(ROOT, "Program")

OSINT_SCRIPT = os.path.join(PROGRAM, "Osint.py")
ROBLOX_SCRIPT = os.path.join(PROGRAM, "Osint_Roblox.py")
DISCORD_SCRIPT = os.path.join(PROGRAM, "Discord_Tool.py")
BLUIDER_STREALER_SCRIPT = os.path.join(PROGRAM, "Bluider_Strealer.py")

def clear():
    os.system("cls" if IS_WINDOWS else "clear")

def slow_print(text, delay=0.0008):
    for ch in text:
        print(ch, end="", flush=True)
        time.sleep(delay)
    print()

def display_interface():
    clear()
    slow_print(C + ASCII_LOGO + R)
    for line in FRAME:
        print(C + line.center(80) + R)
    print()
    print(C + "[1] OSINT Tools".center(80) + R)
    print(C + "[2] OSINT Roblox".center(80) + R)
    print(C + "[3] Discord Tool".center(80) + R)
    print(C + "[4] Bluider Strealer".center(80) + R)
    print(C + "[0] Quit".center(80) + R)

def launch_script(script_path):
    if not os.path.isfile(script_path):
        print(C + f"Fichier introuvable : {script_path}" + R)
        input("\nAppuyez sur Entrée pour revenir au menu...")
        return
    try:
        if IS_WINDOWS:
            subprocess.run(f'start cmd /k python "{script_path}"', shell=True)
        else:
            subprocess.run([sys.executable, script_path])
        input("\nAppuyez sur Entrée pour revenir au menu...")
    except Exception as e:
        print(C + f"Erreur lors de l'exécution : {e}" + R)
        input("\nAppuyez sur Entrée pour revenir au menu...")

def main():
    if IS_WINDOWS:
        os.system('color')
    while True:
        display_interface()
        choice = input(C + "\nuser@kernel: " + R).strip().lower()
        if choice == "1":
            launch_script(OSINT_SCRIPT)
        elif choice == "2":
            launch_script(ROBLOX_SCRIPT)
        elif choice == "3":
            launch_script(DISCORD_SCRIPT)
        elif choice == "4":
            launch_script(BLUIDER_STREALER_SCRIPT)
        elif choice in ("0", "q", "quit", "exit"):
            break
        else:
            print(C + "Choix invalide." + R)
            time.sleep(0.7)

if __name__ == "__main__":
    main()