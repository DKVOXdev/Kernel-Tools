import subprocess
import os

BLUE = "\033[96m"
BOLD = "\033[1m"
RESET = "\033[0m"
RED = "\033[31m"
GREEN = "\033[32m"

name_art = """
 _        _______  _______  _        _______  _                   __
| \\    /\\(  ____ \\(  ____ )( (    /|(  ____ \\( \\        |\\     /|/  \\
|  \\  / /| (    \/| (    )||  \\  ( || (    \/| (        | )   ( |\\/ ) )
|  (_/ / | (__    | (____)||   \\ | || (__    | |        | |   | |  | |
|   _ (  |  __)   |     __)| (\\ \\) ||  __)   | |        ( (   ) )  | |
|  ( \\ \\ | (      | (\\ (   | | \\   || (      | |         \\ \\_/ /   | |
|  /  \\ \\| (____/\\| ) \\ \\__| )  \\  || (____/\\| (____/\\    \\   /  __) (_
|_/    \\/(_______/|/   \\__/|/    )_)(_______/(_______/     \\_/   \\____/
"""

FRAME = [
    "╔══════════════════╗",
    "║   Multi-Tool     ║",
    "║     by DKVOX     ║",
    "╚══════════════════╝"
]

BASE_DIR = "/data/data/com.termux/files/home/Kernel-Tools/Program"

OPTIONS = {
    "Lookup Ip": "LookupIp.py",
    "Username Tracker": "UsernameTracker.py",
    "Phone Lookup": "PhoneLookup.py",
    "Instagram Tracker": "InstagramTracker.py",
    "Mail Info": "MailInfo.py"
}

def clear_console():
    os.system("clear" if os.name != "nt" else "cls")

def display_interface():
    clear_console()
    for line in name_art.splitlines():
        print(BLUE + line.center(80) + RESET)
    for line in FRAME:
        print(BLUE + line.center(80) + RESET)
    print()
    for i, opt in enumerate(OPTIONS, 1):
        print(BLUE + f"[{i}] {opt}".center(80) + RESET)
    print(BLUE + "[0] Quit".center(80) + RESET)

def run_script(script_name):
    full_path = os.path.join(BASE_DIR, script_name)
    if os.path.isfile(full_path):
        subprocess.run(["python3", full_path])
    else:
        print(RED + f"⚠️  Fichier introuvable : {full_path}" + RESET)
        input("Appuyez sur Entrée pour continuer...")

def main():
    while True:
        display_interface()
        choice = input(BLUE + "\nuser@kernel: " + RESET).strip()
        if choice == "0":
            print(GREEN + "\nBye!" + RESET)
            break
        if not choice.isdigit() or int(choice) not in range(1, len(OPTIONS) + 1):
            print(RED + "\nChoix invalide." + RESET)
            input("Appuyez sur Entrée pour continuer...")
            continue
        opt_name = list(OPTIONS.keys())[int(choice) - 1]
        run_script(OPTIONS[opt_name])
        input("\nAppuyez sur Entrée pour revenir au menu...")

if __name__ == "__main__":
    main()
