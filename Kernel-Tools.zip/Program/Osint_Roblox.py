#!/usr/bin/env python3
import os
import subprocess
import sys
import time

C = "\033[96m"
R = "\033[0m"

ASCII_LOGO = r"""
 _        _______  _______  _        _______  _                   __
| \    /\(  ____ \(  ____ )( (    /|(  ____ \( \        |\     /|/  \
|  \  / /| (    \/| (    )||  \  ( || (    \/| (        | )   ( |\/ ) )
|  (_/ / | (__    | (____)||   \ | || (__    | |        | |   | |  | |
|   _ (  |  __)   |     __)| (\ \) ||  __)   | |        ( (   ) )  | |
|  ( \ \ | (      | (\ (   | | \   || (      | |         \ \_/ /   | |
|  /  \ \| (____/\| ) \ \__| )  \  || (____/\| (____/\    \   /  __) (_
|_/    \/(_______/|/   \__/|/    )_)(_______/(_______/     \_/   \____/
"""

FRAME = [
    "╔══════════════════╗",
    "║   Multi-Tool     ║",
    "║     by DKVOX     ║",
    "╚══════════════════╝"
]

ROOT = "/data/data/com.termux/files/home/Kernel-Tools"
PROGRAM = os.path.join(ROOT, "Program")

SCRIPTS = {
    "Pseudo Info": "PseudoInfo.py",
    "Roblox Id Info": "RobloxIdInfo.py",
    "Roblox Cookie Login Info": "RobloxCookieLoginInfo.py",
    "Roblox Login Info": "RobloxLoginInfo.py"
}

def clear():
    os.system("clear" if os.name != "nt" else "cls")

def slow_print(text, delay=0.0008):
    for ch in text:
        print(ch, end="", flush=True)
        time.sleep(delay)
    print()

def display_interface():
    clear()
    slow_print(C + ASCII_LOGO + R)
    for line in FRAME:
        print(C + line.center(80) + R)
    print()
    for i, name in enumerate(SCRIPTS.keys(), 1):
        print(C + f"[{i}] {name}".center(80) + R)
    print(C + "[0] Quit".center(80) + R)

def launch_script(script_name):
    path = os.path.join(PROGRAM, script_name)
    if not os.path.isfile(path):
        print(C + f"⚠️  Script introuvable : {path}" + R)
        input("Appuyez sur Entrée pour continuer...")
        return
    try:
        subprocess.run([sys.executable, path], cwd=PROGRAM)
    except Exception as e:
        print(C + f"Erreur lors de l'exécution : {e}" + R)
        input("Appuyez sur Entrée pour continuer...")

def main():
    while True:
        display_interface()
        choice = input(C + "\nuser@kernel: " + R).strip()
        if choice == "0":
            print(C + "\nBye !" + R)
            break
        if not choice.isdigit() or int(choice) not in range(0, len(SCRIPTS) + 1):
            print(C + "Choix invalide." + R)
            time.sleep(0.7)
            continue
        idx = int(choice)
        if idx == 0:
            print(C + "\nBye !" + R)
            break
        script_name = list(SCRIPTS.values())[idx - 1]
        launch_script(script_name)

if __name__ == "__main__":
    main()
